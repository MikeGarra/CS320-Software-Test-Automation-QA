package SNHU_320_Appointment_Assignment;

//import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	void testAppointmentConstructor() {
		Calendar c = Calendar.getInstance();
		c.set(2023, 05, 31, 6, 40);
		Date date = c.getTime();
		
		System.out.println("Today's date is " + date);
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Appointment("1234567890A", date, "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Appointment(null, date, "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Appointment("1234567890", date, "TaskDescriptionIsTooLongForItToWorkInThisDescriptionSpot"
					+ "TaskDescriptionIsTooLongForItToWorkInThisDescriptionSpot" 
					+ "TaskDescriptionIsTooLongForItToWorkInThisDescriptionSpot");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Appointment(null, date, "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Appointment("1234567890", null, "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Appointment("1234567890", date, null);
		});
	}
	
	@Test
	void testAppointmentGetters() {
		Calendar c = Calendar.getInstance();
		c.set(2023, 05, 31, 6, 40);
		Date date = c.getTime();
		
		Appointment appointment = new Appointment("1234567890", date, "TaskDescription");
		Assertions.assertTrue(appointment.GetID().equals("1234567890"));
		Assertions.assertTrue(appointment.GetDate().equals(date));
		Assertions.assertTrue(appointment.GetDescription().equals("TaskDescription"));
		}
	
	@Test
	void testDate() {
		Calendar c = Calendar.getInstance();
		c.set(2023, 05, 31, 6, 40);
		Date date = c.getTime();
		
		Appointment appointment = new Appointment("1234567890", date, "TaskDescription");
		appointment.SetApptDate(date);
		Assertions.assertTrue(appointment.GetDate().equals(date));
	}
	
	@Test
	void testDescription() {
		Calendar c = Calendar.getInstance();
		c.set(2023, 05, 31, 6, 40);
		Date date = c.getTime();
		
		Appointment appointment = new Appointment("1234567890", date, "TaskDescription");
		appointment.SetApptDescription("TaskDescription");
		Assertions.assertTrue(appointment.GetDescription().equals("TaskDescription"));
	}
	
	@Test
	void testAppointmentSetters() {
		Calendar c = Calendar.getInstance();
		c.set(2023, 05, 31, 6, 40);
		Date date = c.getTime();
		
		Appointment appointment = new Appointment("1234567890", date, "TaskDescription");
	
		appointment.SetApptDate(date);
		appointment.SetApptDescription("NewDescription");
		Assertions.assertTrue(appointment.GetDate().equals(date));
		Assertions.assertTrue(appointment.GetDescription().equals("NewDescription"));
	}
}
