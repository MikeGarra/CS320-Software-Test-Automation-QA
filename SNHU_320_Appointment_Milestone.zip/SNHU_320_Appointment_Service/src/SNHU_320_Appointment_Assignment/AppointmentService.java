package SNHU_320_Appointment_Assignment;

import java.util.Date;
import java.util.Random;
import java.util.Vector;


// import SNHU_320_Appointment_Assignment.Appointment;

public class AppointmentService {

	private Vector<Appointment> apptList = new Vector<Appointment>();
	private int apptCount = 0;
	
	public int GetCount() {
		return apptCount;
	}
	
	public Vector<Appointment> GetList(){
		return apptList;
	}
	
	public void ApptAdd(Date date, String description) throws IllegalArgumentException {
		Date today = new Date();
		if(date == null || date.before(today)) {
			throw new IllegalArgumentException("Invalid Appointment Date.");
		}
	
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("This appointment date is not valid.");
		}
		
		String newID = GenerateUniqueID();
		var newAppt = new Appointment(newID, date, description);
		apptList.add(newAppt);
		apptCount = GetCount() +1;
	}
	
	public void AddAppointment(Appointment appointment) {
		apptList.add(appointment);
		apptCount++;
	}
	
	public void DeleteAppointment(String id) throws IllegalArgumentException {
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID, cannot be more than 10 characters");
		}
		
		if(apptList.isEmpty() ) {
			throw new IllegalArgumentException("There are no contacts that can be deleted.");
		}
		
		int index = -1;
		for(Appointment a : apptList) {
			if(a.GetID() == id) {
				index = apptList.indexOf(a);
			}
		}
		
		if(index == -1) {
			throw new IllegalArgumentException("List has no task with that ID.");
		}
		
		else {
			apptList.remove(index);
			apptCount--;
			System.out.println("That task has been removed.");
		}
	}
	
	public String GenerateUniqueID() {
		Random random = new Random();
		int newID = random.nextInt(1000000);
		String uniqueID= Integer.toString(newID);
		
		for(Appointment a: apptList) {
			while(a.GetID() == uniqueID) {
				newID = random.nextInt(1000000);
				uniqueID = Integer.toString(newID);
			}
		}
		
		System.out.println("Your ID was created: " + uniqueID);
		return uniqueID;
	}
}
