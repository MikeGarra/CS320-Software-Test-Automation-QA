package SNHU_320;

import java.util.Random;
import java.util.Vector;
import java.util.Scanner;
//import SNHU_320.Contact;

public class ContactService {
	
	private Vector<Contact> contactList = new Vector<Contact>();
	private  int contactAmount = 0;
	
	public int getContactAmount() {
		return contactAmount;
	}
	
	public Vector<Contact> getContactlist() {
		return contactList;
	}
	
	public void ContactAdd(String id, String first, String last, String number, String address) {
		Contact newContact = new Contact(id, first,  last,  number, address);
		contactList.add(newContact);
		contactAmount++;
	}
	
	public void AddContact(Contact contact) {
		contactList.add(contact);
		contactAmount++;
	}
	
	public void ContactDelete(String id) throws IllegalArgumentException {
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID, cannot be more than 10 characters");
		}
		
		if(contactList.isEmpty() ) {
			throw new IllegalArgumentException("There are no contacts that can be deleted.");
		}
		
		int index = -1;
		for(Contact c : contactList) {
			if(c.getID() == id) {
				index = contactList.indexOf(c);
			}
		}
		
		if(index == -1) {
			throw new IllegalArgumentException("List has no contact with that ID.");
		}
		
		else {
			contactList.remove(index);
			contactAmount--;
			System.out.println("That contact has been removed.");
		}
		
	}
	
	public void ContactUpdate() throws IllegalArgumentException {
		Scanner myObj = new Scanner(System.in);
		
		System.out.println("Enter the Id of the contact you wish to update.");
		String contactID = myObj.nextLine();
		if(contactID == null || contactID.length() > 10) {
			myObj.close();
			throw new IllegalArgumentException("Invalid ID, cannot be more than 10 characters");
		}
		
		int index = -1;
		for(Contact c : contactList) {
			if(c.getID() == contactID) {
				index = contactList.indexOf(c);
			}
		}
		
		if(index == -1) {
			myObj.close();
			System.out.println("List has no contact with that ID.");
			return;
		}
		
		System.out.println("Which area of the ID do you want to Update?");
		
		String selection = myObj.nextLine();
		
		switch(selection.toLowerCase()) {
		
		case "firstname": {
			System.out.println("What is the new first name?");
			selection = myObj.nextLine();
			contactList.get(index).setFirstName(selection);
			break;
		}
		
		case "lastname": {
			System.out.println("What is the new last name?");
			selection = myObj.nextLine();
			contactList.get(index).setLastName(selection);
			break;
		}
		
		case "phonenumber": {
			System.out.println("What is the new number?");
			selection = myObj.nextLine();
			contactList.get(index).setPhoneNumber(selection);
			break;
		}
		
		case "useraddress": {
			System.out.println("What is the new address?");
			selection = myObj.nextLine();
			contactList.get(index).setUserAddress(selection);
			break;
		}
		
		default: {
			myObj.close();
			throw new IllegalArgumentException("That option does not exsist.");
		}
		}
		myObj.close();
		
	}
	
	public void ContactUpdate(String id, String first, String last, String number, String address) throws IllegalArgumentException {
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Id does not exist.");
		}
		
		if(contactList.isEmpty()) {
			throw new IllegalArgumentException("There are no IDs in list.");
		}
		
		int index = -1;
		for(Contact c : contactList) {
			if(c.getID() == id) {
				index = contactList.indexOf(c);
			}
		}
		
		if(index == -1) {
			throw new IllegalArgumentException("Contact was not found in list.");
		}
		
		Contact temporaryContact = contactList.get(index);
		temporaryContact.setFirstName(first);
		temporaryContact.setLastName(last);
		temporaryContact.setPhoneNumber(number);
		temporaryContact.setUserAddress(address);
		
		contactList.remove(index);
		contactList.add(temporaryContact);
	}
	
	public String UniqueIDGenerator() {
		Random random = new Random();
		int newID = random.nextInt(1000000);
		String uniqueID= Integer.toString(newID);
		
		for(Contact c: contactList) {
			while(c.getID() == uniqueID) {
				newID = random.nextInt(1000000);
				uniqueID = Integer.toString(newID);
			}
		}
		
		System.out.println("Your ID was created: " + uniqueID);
		
		return uniqueID;
	}
	
}
