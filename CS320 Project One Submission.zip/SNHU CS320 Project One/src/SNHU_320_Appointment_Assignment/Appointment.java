package SNHU_320_Appointment_Assignment;

import java.util.Date;

public class Appointment {
	
	private String appointID;
	private Date appointDate;
	private String appointDescrip;
	
	public Appointment(String id, Date date, String description) throws IllegalArgumentException {
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("ID cannot be more than 10 characters.");
		}
		
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("This appointment date is not valid.");
		}
		
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("The description cannot be more than 50 characters.");
		}
		
		appointID = id; 
		appointDate = date;
		appointDescrip = description;
	}
	
	public String GetID() {
		return appointID;
	}

	public Date GetDate() {
		return appointDate;
	}
	
	public String GetDescription() {
		return appointDescrip;
	}
	
	public void SetApptDate (Date date) {
		appointDate = date;
	}

	public void SetApptDescription(String description) {
		appointDescrip = description;
	}
}
