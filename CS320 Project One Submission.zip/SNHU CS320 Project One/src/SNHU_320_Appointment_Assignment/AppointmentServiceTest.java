package SNHU_320_Appointment_Assignment;

import static org.junit.jupiter.api.Assertions.*;

//import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	
	@Test
	void TestApptAdd() {
		Date today = new Date();
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment = new Appointment("123456", today, "Description");
		appointmentService.AddAppointment(appointment);
		assertTrue(!appointmentService.GetList().isEmpty());
		assertTrue(appointmentService.GetList()
				.elementAt(0)
				.GetID()
				.equals("123456"));
		assertTrue(appointmentService.GetCount() > 0);
	}
	
	@Test
	void TestDeleteAppointment() {
		Date today = new Date();
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment = new Appointment("123456", today, "Description");
		appointmentService.AddAppointment(appointment);
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			appointmentService.DeleteAppointment(null);
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			appointmentService.DeleteAppointment("12345678901");
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			appointmentService.DeleteAppointment("1234567890");
	});
		
		appointmentService.AddAppointment(appointment);
		
		appointmentService.DeleteAppointment("123456");
		
		assertTrue(!appointmentService.GetList().isEmpty());
		assertTrue(appointmentService.GetCount() != 0);
		
		appointmentService.DeleteAppointment("123456");
		
		assertTrue(appointmentService.GetCount() == 0);
		assertTrue(appointmentService.GetList().isEmpty());
	}

	
}