package SNHU_320_Task_Assignment;

public class Task {

	private String taskID;				//No longer than 10 characters
	private String taskName;			//No longer than 20 characters
	private String objDescription;		//No longer than 50 characters
	
	public Task(String id, String name, String description) throws IllegalArgumentException {
		
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("ID cannot be more than 10 characters.");
		}
		
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Name cannot be more than 20 characters.");
		}
		
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description cannot be more than 50 characters.");
		}
		
		taskID = id;
		taskName = name;
		objDescription = description; 
	}
	
	public String GetID() {
		return taskID;
	}
	
	public String GetName() {
		return taskName;
	}
	
	public String GetDescription() {
		return objDescription;
	}
	
	public void SetName(String name) {
		taskName = name;
	}
	
	public void SetDescription(String description) {
		objDescription = description;
	}
	
}
