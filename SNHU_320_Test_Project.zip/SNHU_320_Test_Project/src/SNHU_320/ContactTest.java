package SNHU_320;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
//import SNHU_320.Contact;

class ContactTest {

	@Test
	void testNullContactArgument() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null, null, null, null, null);
		});
	}
	
	@Test
	void testGettersAndContact() {
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		assertTrue(contact.getFullName().equals("Jason Andrews"));
		assertTrue(contact.getPhoneNumber().equals("6517884235"));
		assertTrue(contact.getUserAddress().equals("12 Park Ave"));
		assertTrue(contact.getID().equals("123456"));
	}
	
	@Test
	void testFirstAndLastName() {
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		contact.setFirstName("James");
		contact.setLastName("Stevenson");
		assertTrue(contact.getFullName().equals("James Stevenson"));
	}
	
	@Test
	void testPhoneNumberAndUserAddress() {
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		contact.setPhoneNumber("6518774564");
		contact.setUserAddress("322 Raceway Blvd");
		assertTrue(contact.getPhoneNumber().equals("6518774564"));
		assertTrue(contact.getUserAddress().equals("322 Raceway Blvd"));
	}
	
	void testNullSetAttributes() {
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setFirstName(null);
	});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setLastName(null);
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setPhoneNumber(null);
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setUserAddress(null);
	});		
	}
	
	@Test
	void testGetters() {
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		assertTrue(contact.getFullName().equals("Jason Andrews"));
		assertTrue(contact.getPhoneNumber().equals("6517884235"));
		assertTrue(contact.getUserAddress().equals("12 Park Ave"));
		assertTrue(contact.getID().equals("123456"));
	}
	
}
