package SNHU_320;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import SNHU_320.Contact;
import SNHU_320.ContactService;

class ContactServiceTest {

	@Test
	void testAddContactFunction() {
		ContactService contactService = new ContactService();
		//String testID = contactService.UniqueIDGenerator();
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		contactService.AddContact(contact);
		assertTrue(!contactService.getContactlist().isEmpty());
		assertTrue(contactService
					.getContactlist()
					.elementAt(0)
					.getID()
					.equals("123456"));
		assertTrue(contactService.getContactAmount() > 0);
	}
	
	@Test
	void testDeleteContactFunction() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		contactService.AddContact(contact);
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.ContactDelete(null);
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.ContactDelete("12345678901");
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.ContactDelete("1234567890");
	});
		
		contactService.AddContact(contact);
		
		contactService.ContactDelete("123456");
		
		assertTrue(!contactService.getContactlist().isEmpty());
		assertTrue(contactService.getContactAmount() != 0);
		
		contactService.ContactDelete("123456");
		
		assertTrue(contactService.getContactAmount() == 0);
		assertTrue(contactService.getContactlist().isEmpty());
	}
	
	@Test
	void testContactUpdateFunctionErrors() {
		ContactService contactService = new ContactService();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.ContactUpdate();
	});
	}
	
	@Test
	void testContactUpdateFunction() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("123456", "Jason", "Andrews", "6517884235", "12 Park Ave");
		contactService.AddContact(contact);
		contactService.ContactUpdate("123456", "Adam", "Andrews", "6517884235", "12 Park Ave");
		assertTrue(contactService
				.getContactlist()
				.elementAt(0)
				.getFullName()
				.equals("Adam Andrews"));
	}

}
