package SNHU_320;

public class Contact {

	private Contact myContact;
	
	private final String userID;		//cannot be more than 10 characters
	private String firstName;			//cannot be more than 10 characters
	private String lastName;			//cannot be more than 10 characters
	private String phoneNumber;			//must equal 10 characters
	private String userAddress;			//cannot be more than 30 characters
	
	public Contact(String id, String first, String last, String number, String address) throws IllegalArgumentException {
		
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID, cannot be more than 10 characters");
		}
		
		if(first == null || first.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name, cannot be more than 10 characters");
		}
		
		if(last == null || last.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name, cannot be more than 10 characters");
		}
		
		if(number == null || number.length() != 10) {
			throw new IllegalArgumentException("Invalid PhoneNumber, must be 10 digits");
		}
		
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address, cannot be more than 30 characters");
		}
		
		userID = id;
		firstName = first;
		lastName = last;
		phoneNumber = number;
		userAddress = address;
	}
	
	public String getID() {
		return userID;
	}
	
	public String getFullName() {
		return firstName + " " + lastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getUserAddress() {
		return userAddress;
	}
	
	public void setFirstName(String first) {
		firstName = first;
	}
	
	public void setLastName(String last) {
		lastName = last;
	}
	
	public void setPhoneNumber(String number) {
		phoneNumber = number;
	}
	
	public void setUserAddress(String address) {
		userAddress = address;
	}
	
}
