package SNHU_320_Task_Assignment;

import java.util.Random;
import java.util.Vector;



import java.util.Scanner;

//import SNHU_320_Task_Assignment.Task;


public class TaskService {

	private Vector<Task> taskList = new Vector<Task>();
	private int taskCount = 0;
	
	public int GetCount() {
		return taskCount;
	}
	
	public Vector<Task> GetList() {
		return taskList;
	}
	
	public void TaskAdd(String id, String name, String description) {
		Task newTask = new Task(id, name, description);
		taskList.add(newTask);
		taskCount++;
	}
	
	public void AddTask(Task task) {
		taskList.add(task);
		taskCount++;
	}
	
	public void TaskDelete(String id) throws IllegalArgumentException {
	if(id == null || id.length() > 10) {
		throw new IllegalArgumentException("Invalid ID, cannot be more than 10 characters");
	}
	
	if(taskList.isEmpty() ) {
		throw new IllegalArgumentException("There are no contacts that can be deleted.");
	}
	
	int index = -1;
	for(Task t : taskList) {
		if(t.GetID() == id) {
			index = taskList.indexOf(t);
		}
	}
	
	if(index == -1) {
		throw new IllegalArgumentException("List has no task with that ID.");
	}
	
	else {
		taskList.remove(index);
		taskCount--;
		System.out.println("That task has been removed.");
	}
	
	}
	
	public void TaskUpdate() throws IllegalArgumentException {
		Scanner myObj = new Scanner(System.in);
		
		System.out.println("Enter the Id of the Task you wish to update.");
		String taskID = myObj.nextLine();
		if(taskID == null || taskID.length() > 10) {
			myObj.close();
			throw new IllegalArgumentException("Invalid ID, cannot be more than 10 characters");
		}
		
		int index = -1;
		for(Task t : taskList) {
			if(t.GetID() == taskID) {
				index = taskList.indexOf(t);
			}
		}
		
		if(index == -1) {
			myObj.close();
			throw new IllegalArgumentException("List has no task with that ID.");
		}
		
		System.out.println("Which area of the ID do you want to Update?");
		
		String selection = myObj.nextLine();
		
		switch(selection.toLowerCase()) {
		
		case "taskname": {
			System.out.println("What is the new name?");
			selection = myObj.nextLine();
			taskList.get(index).SetName(selection);
			break;
		}
		
		case "taskdescription": {
			System.out.println("What is the new descprition?");
			selection = myObj.nextLine();
		taskList.get(index).SetDescription(selection);
			break;
		}
		
		default: {
			myObj.close();
			throw new IllegalArgumentException("That option does not exsist.");
		}
		}
		myObj.close();
		
	}
	
	public void TaskUpdate(String id, String name, String description) {
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Id does not exist.");
		}
		
		if(taskList.isEmpty()) {
			throw new IllegalArgumentException("There are no IDs in list.");
		}
		
		int index = -1;
		for(Task t : taskList) {
			if(t.GetID() == id) {
				index = taskList.indexOf(t);
			}
		}
		
		if(index == -1) {
			throw new IllegalArgumentException("Task was not found in list.");
		}
		
		Task temporaryTask = taskList.get(index);
		temporaryTask.SetName(name);
		temporaryTask.SetDescription(description);
		
		taskList.remove(index);
		taskList.add(temporaryTask);
	}
	
	public String UniqueIDGenerator() {
		Random random = new Random();
		int newID = random.nextInt(1000000);
		String uniqueID= Integer.toString(newID);
		
		for(Task t: taskList) {
			while(t.GetID() == uniqueID) {
				newID = random.nextInt(1000000);
				uniqueID = Integer.toString(newID);
			}
		}
		
		System.out.println("Your ID was created: " + uniqueID);
		
		return uniqueID;
	
	}
	
}

