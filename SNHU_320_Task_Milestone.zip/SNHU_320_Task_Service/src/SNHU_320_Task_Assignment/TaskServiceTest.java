package SNHU_320_Task_Assignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	
	@Test
	void testAddTask() {
		TaskService taskService = new TaskService();
		Task task = new Task("123456", "Joseph", "Description");
		taskService.AddTask(task);
		assertTrue(!taskService.GetList().isEmpty());
		assertTrue(taskService.GetList()
				.elementAt(0)
				.GetID()
				.equals("123456"));
		assertTrue(taskService.GetCount() > 0);
	
	}
	
	@Test
	void testRemoveTask() {
		TaskService contactService = new TaskService();
		Task task = new Task("123456", "Joseph", "Description");
		contactService.AddTask(task);
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.TaskDelete(null);
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.TaskDelete("12345678901");
	});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.TaskDelete("1234567890");
	});
		
		contactService.AddTask(task);
		
		contactService.TaskDelete("123456");
		
		assertTrue(!contactService.GetList().isEmpty());
		assertTrue(contactService.GetCount() != 0);
		
		contactService.TaskDelete("123456");
		
		assertTrue(contactService.GetCount() == 0);
		assertTrue(contactService.GetList().isEmpty());
	}
	
	@Test
	void testTaskUpdateFunctionErrors() {
		TaskService taskService = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			taskService.TaskUpdate();
	});
	}
	
	@Test
	void testUpdateTask() {
		TaskService taskService = new TaskService();
		Task task = new Task("123456", "Joseph", "Description");
		taskService.AddTask(task);
		taskService.TaskUpdate("123456", "Adam", "Description");
		assertTrue(taskService
				.GetList()
				.elementAt(0)
				.GetName()
				.equals("Adam"));
		}
		
	
}
