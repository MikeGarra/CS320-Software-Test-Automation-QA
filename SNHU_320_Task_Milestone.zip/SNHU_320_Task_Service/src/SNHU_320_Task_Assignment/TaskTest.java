package SNHU_320_Task_Assignment;

//import static org.junit.Assert.assertTrue;
//import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



//import SNHU_320_Task_Assignment.Task;


class TaskTest {

	@Test
	void testTaskConstructor() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("1234567890A", "TaskName", "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("1234567890", "TaskNameABCDEFGHIJKLMNOPQRSTUVWXYZ", "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("1234567890", "TaskName", "TaskDescriptionIsTooLongForItToWorkInThisDescriptionSpot"
					+ "TaskDescriptionIsTooLongForItToWorkInThisDescriptionSpot" 
					+ "TaskDescriptionIsTooLongForItToWorkInThisDescriptionSpot");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task(null, "TaskName", "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("1234567890", null, "TaskDescription");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("1234567890", "TaskName", null);
		});
	}
	
	@Test
	void testTaskGetters() {
		Task task = new Task("1234567890", "TaskName", "TaskDescription");
		Assertions.assertTrue(task.GetID().equals("1234567890"));
		Assertions.assertTrue(task.GetName().equals("TaskName"));
		Assertions.assertTrue(task.GetDescription().equals("TaskDescription"));
		}
	
	@Test
	void testName() {
		Task task = new Task("1234567890", "TaskName", "TaskDescription");
		task.SetName("TaskName");
		Assertions.assertTrue(task.GetName().equals("TaskName"));
	}
	
	@Test
	void testDescription() {
		Task task = new Task("1234567890", "TaskName", "TaskDescription");
		task.SetDescription("TaskDescription");
		Assertions.assertTrue(task.GetDescription().equals("TaskDescription"));
	}
	
	@Test
	void testTaskSetters() {
		Task task = new Task("1234567890", "TaskName", "TaskDescription");
	
		task.SetName("NewName");
		task.SetDescription("NewDescription");
		Assertions.assertTrue(task.GetName().equals("NewName"));
		Assertions.assertTrue(task.GetDescription().equals("NewDescription"));
	}
}
